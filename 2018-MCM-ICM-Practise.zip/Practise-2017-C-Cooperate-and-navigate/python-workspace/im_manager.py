#!python3

from PIL import Image

res_path = '/home/zhiquanwang/CodeRepository/2018-MCM-ICM-Repository/Practise-2017-C-Cooperate-and-navigate/resource/'

im = Image.open(res_path+'highway_system_points.jpg')
im.show()